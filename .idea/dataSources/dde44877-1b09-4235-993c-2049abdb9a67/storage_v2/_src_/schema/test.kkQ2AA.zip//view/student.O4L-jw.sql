create view student as
select `test`.`tb_user`.`id` AS `id`,`test`.`tb_user`.`email` AS `email`,`test`.`tb_user`.`name` AS `name`
from `test`.`tb_user`;

